# Axios JavaScript Sample Application

This is the sample app of the tutorial __Getting Started With Axios (Accessing REST Web Services / HTTP APIs in JavaScript)__ available on [CodingTheSmartWay.com](http://codingthesmartway.com/).

## Online Course
Check out the online course: [The Complete JavaScript Course: Build a Real-World Project](http://codingthesmartway.com/courses/complete-javascript/)
